# FAQ

**`bundle deploy` says "no host configured" / authentication error.**
Run `databricks auth login --host <url>`, then `databricks auth profiles`. If you have several profiles,
pass `-p <profile>` or set `workspace.host` in `databricks.yml`.

**Job fails with "catalog workspace not found" or permission denied on CREATE SCHEMA.**
Your Free Edition default catalog may have a different name. Check it with `SHOW CATALOGS;` and redeploy with
`--var="catalog=<name>"`.

**The SQL notebook fails on `IDENTIFIER(:catalog)`.**
Needs a recent serverless runtime (it's the default). As a workaround, hardcode `USE CATALOG workspace; USE SCHEMA cascade_finops;`.

**Can I query the real `system.billing.usage` in my own workspace?**
Try it. Some system tables are visible in Free Edition, and it's good practice for the syntax. **The customer's data is
the snapshot in `cascade_finops`**, though, so build your analysis on that.

**Can I change `generate_system_tables.py`?**
No. Treat it as the customer's export. Everything else is fair game, including rewriting the customer's partial code.

**The numbers in `gold_daily_cost` look high.**
Good catch? That's for you to decide. Be ready to explain what you found and why it matters.

**Do I need a dashboard / app / Genie?**
No. Use whatever presentation layer best supports *your story* to *this audience*. A tidy notebook is valid.

**How do I export an AI/BI dashboard into the bundle?**
`databricks bundle generate dashboard --existing-path "/Workspace/Users/<you>/<name>.lvdash.json"`, then reference it in
a `resources/*.dashboard.yml`. This is optional, but it supports a strong "it's code, it's repeatable" answer for the CTO.
