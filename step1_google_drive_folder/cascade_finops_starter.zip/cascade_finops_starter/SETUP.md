# SETUP: deploy into Databricks Free Edition with DABs

Budget **15 minutes** for this. If it takes longer, see `FAQ.md`. Don't spend your build time on tooling.

## 1. Install & authenticate the Databricks CLI (v0.250+ recommended)
```bash
# macOS
brew tap databricks/tap && brew install databricks
# Linux / WSL
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh

databricks --version
databricks auth login --host https://<your-free-edition-host>.cloud.databricks.com
#   -> opens a browser (OAuth U2M). Saves a profile in ~/.databrickscfg
databricks current-user me          # sanity check
```

## 2. Validate, deploy, run
From this folder:
```bash
databricks bundle validate -t dev
databricks bundle deploy   -t dev
databricks bundle run      -t dev cascade_setup      # about 2–5 min on serverless
```
In dev mode, the job shows up in **Jobs & Pipelines** as `[dev <your name>] cascade_setup`.

Override the target catalog/schema if needed:
```bash
databricks bundle deploy -t dev --var="catalog=workspace" --var="schema=cascade_finops"
```

## 3. Verify
In a SQL editor or notebook:
```sql
SELECT COUNT(*) FROM workspace.cascade_finops.billing_usage;        -- ~27k rows
SELECT date_trunc('month', usage_date) m, ROUND(SUM(list_cost_usd))
FROM workspace.cascade_finops.gold_daily_cost GROUP BY 1 ORDER BY 1;
```

## 4. Iterate
- Edit files locally, then `databricks bundle deploy -t dev` to sync.
- Or work directly in the workspace under `~/.bundle/cascade_finops/dev/files/`. **Remember that a later
  `bundle deploy` overwrites workspace edits.** Pick one source of truth.
- Add new notebooks or jobs to `resources/*.yml` so your demo is reproducible (a nice talking point for the CTO).

## Free Edition constraints to remember
- **Serverless only**: no classic clusters, no instance pools, and you **cannot create compute policies** there.
- One SQL warehouse (2X-Small serverless starter). Rate limits apply. A Credit Boost is available if you hit the cap.
- You can build: notebooks, jobs, Lakeflow Declarative Pipelines, AI/BI Dashboards, Genie Spaces, Databricks Apps (limited), UC objects.
