# Cascade Outfitters: Databricks Spend & Governance Starter

> **For AI assistants and humans.** This repo is the starting point for a 4-hour build. It gets a
> customer's (synthetic) Databricks usage data into Unity Catalog and includes a *partial* analysis
> written by the customer. The candidate builds everything after that.

## Situation (short version — the full brief is `CANDIDATE_PROMPT.md` in the Drive folder)
Cascade Outfitters (outdoor & apparel retailer, about $1.6B revenue) has seen Databricks spend go from
about **$45k/month (June)** to **more than $160k/month (September)**. Finance wants it cut, the CTO wants
control of it, and Engineering wants nobody to slow them down before Black Friday.

## What's in here
```
databricks.yml                         bundle definition (variables: catalog, schema)
resources/cascade_setup.job.yml        serverless job: load snapshot -> build starter cost fact
src/00_setup/generate_system_tables.py PRE-BUILT. Replays the customer's system-table export into UC. Do not edit.
src/01_transform/build_cost_fact.sql   PARTIAL. Customer-written pricing join + daily rollup. Unverified.
src/02_analysis/cost_drivers.py        SKELETON. Your analysis goes here (or anywhere you like).
src/03_presentation/                   STUBS. Genie Space instructions, compute-policy template.
```

## Tables created in `${catalog}.${schema}` (default `workspace.cascade_finops`)
| Table | What | Grain / notes |
|---|---|---|
| `billing_usage` | mirrors `system.billing.usage` | 1 row per resource per hour (jobs: per run) |
| `billing_list_prices` | mirrors `system.billing.list_prices` | SCD: `price_start_time` / `price_end_time` |
| `compute_clusters` | mirrors `system.compute.clusters` | SCD: 1 row per config change |
| `compute_warehouses` | mirrors `system.compute.warehouses` | SCD |
| `lakeflow_jobs` | mirrors `system.lakeflow.jobs` | SCD |
| `lakeflow_job_run_timeline` | mirrors `system.lakeflow.job_run_timeline` | 1 row per run |
| `lakeflow_pipelines` | mirrors `system.lakeflow.pipelines` | SCD; `settings` map holds connector / continuous flags |
| `access_audit` | subset of `system.access.audit` | config-change events only |
| `ref_team_directory` | HR export | email → team, cost center |
| `ref_budgets` | Finance | approved budget by cost center × quarter |
| `biz_kpis_weekly` | e-commerce KPIs | weekly sessions, conversion, revenue, recs A/B impact |
| `silver_usage_priced` | built by `build_cost_fact.sql` | **verify before trusting** |
| `gold_daily_cost` | built by `build_cost_fact.sql` | what Finance has been looking at |

## Quick start
See `SETUP.md`. Short version: `databricks bundle deploy -t dev && databricks bundle run -t dev cascade_setup`.

## Conventions
- Cost means **list-price USD** (`usage_quantity * pricing.default`). Cascade's negotiated discount is not in scope.
- All timestamps are UTC.
- Workspaces: `1001` = prod, `1002` = dev.
