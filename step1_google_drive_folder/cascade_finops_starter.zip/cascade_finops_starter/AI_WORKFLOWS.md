# AI_WORKFLOWS: using AI assistants on this project

These are hints for working with Claude Code, Cursor, the Databricks Assistant, or the AI-Dev-Kit MCP servers.

## Give your assistant context first
> "Read README.md, SETUP.md and FAQ.md. The data lives in `<catalog>.<schema>`; table schemas are in README.md.
> Don't modify src/00_setup. Treat src/01_transform as unverified customer code."

## Prompts that tend to work
- "Write a Databricks SQL query against `billing_usage` + `billing_list_prices` that prices usage using the price
  valid at `usage_start_time` (SCD join). Then reconcile the row count against raw `billing_usage`."
- "Normalize `custom_tags` so any key matching cost_center (case-insensitive, with or without an underscore) maps to a
  single upper-cased `cost_center` column. Fall back to the owner's cost center from `ref_team_directory`."
- "For each all-purpose cluster, compute the % of billed hours that fall outside 08:00–19:00 on weekdays."
- "Compare run frequency per job in `lakeflow_job_run_timeline` by week. Flag step changes."
- "Generate an AI/BI dashboard spec / Genie instructions for these curated tables: ..."

## Databricks-native helpers
- **Databricks Assistant** (in notebooks and the SQL editor): `/explain`, `/fix`, and generating SQL from comments.
- **Genie**: natural-language Q&A over curated tables. Add instructions and example SQL.
- **AI-Dev-Kit** (optional): MCP server and skills so a local agent can run SQL, create jobs or dashboards in your workspace.

## Guardrails
- Verify every number the AI produces against a second query before it goes on a slide.
- Time-box AI rabbit holes to 15 minutes. If it isn't converging, simplify the ask.
