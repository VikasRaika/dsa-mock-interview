# Databricks notebook source
# MAGIC %md
# MAGIC # 02 · Cost driver analysis (SKELETON — yours to build)
# MAGIC
# MAGIC Questions Cascade's leadership has asked (see the prompt for context):
# MAGIC 1. **What happened?** Where did spend go from ~$45k/month to "$160k+" — which products, workloads, teams, and when?
# MAGIC 2. **How much of it is waste vs. value?** Be specific and defensible. Show your math.
# MAGIC 3. **Who owns it?** Finance cannot do chargeback today.
# MAGIC 4. **What do we do about it, in what order, and what does each step save?**
# MAGIC 5. **How do we stop it happening again** without slowing engineering down before peak season?
# MAGIC
# MAGIC Suggested structure below — change it freely. A clean notebook with clear outputs is a valid demo.

# COMMAND ----------

dbutils.widgets.text("catalog", "workspace")
dbutils.widgets.text("schema", "cascade_finops")
catalog, schema = dbutils.widgets.get("catalog"), dbutils.widgets.get("schema")
spark.sql(f"USE CATALOG {catalog}")
spark.sql(f"USE SCHEMA {schema}")

# COMMAND ----------

# MAGIC %md ## 0. Trust the numbers first
# MAGIC Before showing an executive a single dollar figure: does `silver_usage_priced` reconcile to raw usage?

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 1. Spend trend & step changes (what changed, when)

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 2. Top workloads by cost & growth (cluster / job / warehouse / pipeline / endpoint)

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 3. Waste signals
# MAGIC Ideas: compute running when nobody works · schedules more frequent than consumers need · failing jobs
# MAGIC that retry · oversized/always-warm warehouses · no auto-termination · no compute policy.

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 4. Attribution / chargeback (tag hygiene, ownership, budget vs actual)

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 5. Value side of the ledger (what spend is *earning* money?)

# COMMAND ----------

# TODO

# COMMAND ----------

# MAGIC %md ## 6. Recommendations: action · owner · effort · $ impact · risk

# COMMAND ----------

# TODO
