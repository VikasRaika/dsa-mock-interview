# Genie Space — "Cascade Spend Assistant" (STUB)

Optional presentation layer. Business Leader persona wants to "just ask a question and get a number".

## Suggested setup (in the UI: Genie → New)
- Tables: pick the *curated* tables you build (not raw `billing_usage`). Genie is only as good as the model under it.
- Warehouse: the serverless starter warehouse in your workspace.

## General instructions (TODO — write these)
- Define what "cost" means (list price? which table?).
- Define "waste" the way you define it in your analysis.
- Map business words to columns ("team", "cost center", "owner", "project Atlas" ...).

## Sample questions to seed (TODO)
- What did we spend last month by team?
- ...

## Trusted SQL / example queries (TODO)
