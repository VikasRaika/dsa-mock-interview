-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 01 · Starter cost fact (PARTIAL — written by Cascade's platform team)
-- MAGIC
-- MAGIC Alex Kim (Data Platform) started this before handing it to us. It prices DBU usage and builds a
-- MAGIC daily rollup that Finance has *already been looking at*. Alex's note on the handoff:
-- MAGIC
-- MAGIC > "Pricing join is done. Haven't had time to do tag cleanup or attribution. Finance says our numbers
-- MAGIC > look higher than the invoice but I think that's just timing. — A."
-- MAGIC
-- MAGIC Treat everything here as **unverified customer code**.

-- COMMAND ----------

CREATE WIDGET TEXT catalog DEFAULT 'workspace';
CREATE WIDGET TEXT schema DEFAULT 'cascade_finops';

-- COMMAND ----------

USE CATALOG IDENTIFIER(:catalog);
USE SCHEMA IDENTIFIER(:schema);

-- COMMAND ----------

-- Priced usage: one row per usage record with a USD cost.
CREATE OR REPLACE TABLE silver_usage_priced AS
SELECT
  u.record_id,
  u.workspace_id,
  u.usage_date,
  u.usage_start_time,
  u.sku_name,
  u.billing_origin_product,
  u.usage_quantity                         AS dbus,
  p.pricing.default                        AS list_price_usd,
  u.usage_quantity * p.pricing.default     AS list_cost_usd,
  u.custom_tags,
  u.usage_metadata.cluster_id,
  u.usage_metadata.job_id,
  u.usage_metadata.warehouse_id,
  u.usage_metadata.dlt_pipeline_id         AS pipeline_id,
  u.usage_metadata.endpoint_name,
  u.identity_metadata.run_as,
  u.identity_metadata.owned_by,
  u.product_features.is_serverless
FROM billing_usage u
JOIN billing_list_prices p
  ON u.sku_name = p.sku_name
 AND u.cloud    = p.cloud;
-- TODO: tags are messy (cost_center / CostCenter / costcenter, mixed case values). Normalize.
-- TODO: attribute untagged usage (owner -> ref_team_directory?).

-- COMMAND ----------

-- Daily rollup Finance is using.
CREATE OR REPLACE TABLE gold_daily_cost AS
SELECT
  usage_date,
  billing_origin_product,
  custom_tags['cost_center'] AS cost_center,
  SUM(dbus)                  AS dbus,
  SUM(list_cost_usd)         AS list_cost_usd
FROM silver_usage_priced
GROUP BY ALL;

-- COMMAND ----------

SELECT date_trunc('month', usage_date) AS month, ROUND(SUM(list_cost_usd)) AS list_cost_usd
FROM gold_daily_cost
GROUP BY ALL
ORDER BY month;
