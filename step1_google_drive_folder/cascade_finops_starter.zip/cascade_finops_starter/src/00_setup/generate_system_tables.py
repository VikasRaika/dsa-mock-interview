# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Load Cascade Outfitters account snapshot (PRE-BUILT — do not modify)
# MAGIC
# MAGIC Cascade's security team will not grant us direct access to their production account's
# MAGIC `system` catalog before the call. Instead, their platform team exported a **90+ day snapshot**
# MAGIC of the relevant System Tables (plus a few reference tables from Finance / HR) and we replay it
# MAGIC here into Unity Catalog so we can analyse it in our own workspace.
# MAGIC
# MAGIC | Table in this schema | Mirrors (in a real account) |
# MAGIC |---|---|
# MAGIC | `billing_usage` | `system.billing.usage` |
# MAGIC | `billing_list_prices` | `system.billing.list_prices` |
# MAGIC | `compute_clusters` | `system.compute.clusters` (SCD — one row per config change) |
# MAGIC | `compute_warehouses` | `system.compute.warehouses` (SCD) |
# MAGIC | `lakeflow_jobs` | `system.lakeflow.jobs` |
# MAGIC | `lakeflow_job_run_timeline` | `system.lakeflow.job_run_timeline` |
# MAGIC | `lakeflow_pipelines` | `system.lakeflow.pipelines` (SCD) |
# MAGIC | `access_audit` | `system.access.audit` (filtered to config-change events) |
# MAGIC | `ref_team_directory` | HR export — who sits in which team / cost center |
# MAGIC | `ref_budgets` | Finance — approved Databricks budget by cost center & quarter |
# MAGIC | `biz_kpis_weekly` | Digital commerce weekly KPIs (from the e-comm team) |
# MAGIC
# MAGIC Snapshot window: **2026-06-01 → 2026-10-11** (exported on 2026-10-12).
# MAGIC Schemas are simplified versions of the real system tables — column names match where it matters.

# COMMAND ----------

import random
import uuid
from datetime import datetime, timedelta, date

try:
    dbutils.widgets.text("catalog", "workspace")
    dbutils.widgets.text("schema", "cascade_finops")
    CATALOG = dbutils.widgets.get("catalog")
    SCHEMA = dbutils.widgets.get("schema")
    ON_DATABRICKS = True
except NameError:  # running locally (python file.py) for a quick sanity check
    CATALOG, SCHEMA, ON_DATABRICKS = "local", "local", False

random.seed(42)
ACCOUNT_ID = "a1c2-cascade-outfitters"
CLOUD = "AWS"
START = date(2026, 6, 1)
END = date(2026, 10, 11)
WS_PROD, WS_DEV = 1001, 1002
DAYS = [START + timedelta(days=i) for i in range((END - START).days + 1)]

def dt(d, h=0, m=0):
    return datetime(d.year, d.month, d.day, h, m)

def rid(*parts):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "/".join(str(p) for p in parts)))

# COMMAND ----------

# MAGIC %md ## Reference: people, teams, prices

# COMMAND ----------

TEAM_DIRECTORY = [
    # email, display_name, team, cost_center, manager, employment_type
    ("alex.kim@cascadeoutfitters.com", "Alex Kim", "Data Platform", "CC-100", "morgan.reyes@cascadeoutfitters.com", "FTE"),
    ("maria.lopez@cascadeoutfitters.com", "Maria Lopez", "Data Platform", "CC-100", "morgan.reyes@cascadeoutfitters.com", "FTE"),
    ("morgan.reyes@cascadeoutfitters.com", "Morgan Reyes", "Data Platform", "CC-100", "cto@cascadeoutfitters.com", "FTE"),
    ("jordan.patel@cascadeoutfitters.com", "Jordan Patel", "Marketing Analytics", "CC-200", "kelly.chen@cascadeoutfitters.com", "FTE"),
    ("sam.okafor@cascadeoutfitters.com", "Sam Okafor", "Marketing Analytics", "CC-200", "kelly.chen@cascadeoutfitters.com", "FTE"),
    ("priya.nair@cascadeoutfitters.com", "Priya Nair", "Supply Chain Data Science", "CC-300", "dev.sharma@cascadeoutfitters.com", "FTE"),
    ("tom.becker@cascadeoutfitters.com", "Tom Becker", "Supply Chain Data Science", "CC-300", "dev.sharma@cascadeoutfitters.com", "FTE"),
    ("lena.fischer@cascadeoutfitters.com", "Lena Fischer", "Personalization (Project Atlas)", "CC-400", "omar.haddad@cascadeoutfitters.com", "FTE"),
    ("raj.mehta@cascadeoutfitters.com", "Raj Mehta", "Personalization (Project Atlas)", "CC-400", "omar.haddad@cascadeoutfitters.com", "FTE"),
    ("chris.wong@cascadeoutfitters.com", "Chris Wong", "Personalization (Project Atlas)", "CC-400", "omar.haddad@cascadeoutfitters.com", "FTE"),
    ("nina.alvarez@cascadeoutfitters.com", "Nina Alvarez", "Personalization (Project Atlas)", "CC-400", "omar.haddad@cascadeoutfitters.com", "FTE"),
    ("dana.white@cascadeoutfitters.com", "Dana White", "Finance BI", "CC-500", "cfo-office@cascadeoutfitters.com", "FTE"),
    ("eli.brooks@cascadeoutfitters.com", "Eli Brooks", "Finance BI", "CC-500", "cfo-office@cascadeoutfitters.com", "FTE"),
    # NOTE: Stratus Partners contractors are not in the HR directory.
]

LIST_PRICES = [
    # sku_name, usage_unit, price_usd, price_start, price_end
    ("PREMIUM_ALL_PURPOSE_COMPUTE", "DBU", 0.55, datetime(2025, 1, 1), datetime(2026, 9, 1)),
    ("PREMIUM_ALL_PURPOSE_COMPUTE", "DBU", 0.65, datetime(2026, 9, 1), None),  # contract renewal repriced AP compute
    ("PREMIUM_JOBS_COMPUTE", "DBU", 0.15, datetime(2025, 1, 1), None),
    ("PREMIUM_JOBS_SERVERLESS_COMPUTE_US_EAST", "DBU", 0.35, datetime(2025, 1, 1), None),
    ("PREMIUM_SERVERLESS_SQL_COMPUTE_US_EAST", "DBU", 0.70, datetime(2025, 1, 1), None),
    ("PREMIUM_DLT_SERVERLESS_COMPUTE_US_EAST", "DBU", 0.35, datetime(2025, 1, 1), None),
    ("PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_US_EAST", "DBU", 0.07, datetime(2025, 1, 1), None),
]

# COMMAND ----------

# MAGIC %md ## Usage simulation

# COMMAND ----------

usage = []          # billing_usage rows
runs = []           # job_run_timeline rows

def emit(ws, sku, product, start, dbu, tags, run_as, owned_by=None, cluster_id=None, job_id=None,
         job_run_id=None, warehouse_id=None, pipeline_id=None, endpoint=None, serverless=False, photon=False):
    if dbu <= 0:
        return
    usage.append((
        rid("u", ws, sku, start, cluster_id, job_id, job_run_id, warehouse_id, pipeline_id, endpoint),
        ACCOUNT_ID, ws, sku, CLOUD, start, start + timedelta(hours=1), start.date(),
        dict(tags) if tags else {}, "DBU", round(float(dbu), 4),
        (cluster_id, job_id, job_run_id, warehouse_id, pipeline_id, endpoint),
        (run_as, owned_by),
        "ORIGINAL", product, (serverless, photon),
    ))

def weekday(d):
    return d.weekday() < 5

# --- All-purpose clusters ----------------------------------------------------
clusters_scd = []  # compute_clusters rows

def cluster_row(cid, name, owner, create, driver, worker, workers, autoterm, tags, policy, dbr, change_time, delete=None, source="UI", ws=WS_DEV):
    clusters_scd.append((ACCOUNT_ID, ws, cid, name, owner, create, delete, driver, worker, workers, None, None,
                         autoterm, dict(tags), source, policy, dbr, change_time))

# shared, governed analytics cluster (the "good" example)
SHARED = dict(cid="0601-shared-analytics", name="shared-analytics", owner="alex.kim@cascadeoutfitters.com",
              tags={"cost_center": "CC-100", "env": "prod", "team": "data-platform"}, dbu=28, start=date(2026, 6, 1))
cluster_row(SHARED["cid"], SHARED["name"], SHARED["owner"], dt(date(2025, 11, 3)), "m6i.4xlarge", "m6i.4xlarge", 4, 30,
            SHARED["tags"], "pol-standard-shared", "15.4 LTS", dt(date(2025, 11, 3)), ws=WS_PROD)

# Project Atlas GPU exploration cluster — created Jul 18, auto-termination disabled, never stopped
ATLAS = dict(cid="0718-atlas-gpu-exploration", owner="lena.fischer@cascadeoutfitters.com",
             tags={"team": "atlas", "project": "recsys"}, dbu=52, start=dt(date(2026, 7, 18), 15))
cluster_row(ATLAS["cid"], "atlas-gpu-exploration", ATLAS["owner"], ATLAS["start"], "g5.12xlarge", "g5.12xlarge", 4, 0,
            ATLAS["tags"], None, "15.4 LTS ML (GPU)", ATLAS["start"], ws=WS_PROD)

# developer sandboxes — grows from 6 to 14, no policy, inconsistent tags
DEV_CLUSTERS = [
    # cid, name, owner, node, workers, autoterm, dbu/h, start, tags, overnight_prob
    ("0412-dev-alex", "alex-dev", "alex.kim@cascadeoutfitters.com", "m6i.2xlarge", 2, 60, 9, date(2026, 6, 1), {"CostCenter": "CC-100"}, 0.0),
    ("0415-dev-maria", "maria-sandbox", "maria.lopez@cascadeoutfitters.com", "m6i.2xlarge", 2, 120, 9, date(2026, 6, 1), {"cost_center": "CC-100"}, 0.05),
    ("0420-dev-jordan", "jordan-mktg-adhoc", "jordan.patel@cascadeoutfitters.com", "r5.4xlarge", 4, 120, 18, date(2026, 6, 1), {"costcenter": "cc-200"}, 0.10),
    ("0501-dev-priya", "priya-forecasting", "priya.nair@cascadeoutfitters.com", "r5.4xlarge", 4, 60, 18, date(2026, 6, 1), {}, 0.05),
    ("0502-dev-tom", "tom-scratch", "tom.becker@cascadeoutfitters.com", "r5.8xlarge", 6, 0, 30, date(2026, 6, 1), {}, 0.35),
    ("0510-dev-dana", "dana-finance-bi", "dana.white@cascadeoutfitters.com", "m6i.2xlarge", 2, 60, 9, date(2026, 6, 1), {"cost_center": "CC-500"}, 0.0),
    ("0715-dev-raj", "raj-atlas-features", "raj.mehta@cascadeoutfitters.com", "r5.8xlarge", 6, 0, 30, date(2026, 7, 15), {"team": "atlas"}, 0.40),
    ("0715-dev-chris", "chris-atlas-eval", "chris.wong@cascadeoutfitters.com", "r5.4xlarge", 4, 120, 18, date(2026, 7, 15), {"team": "atlas"}, 0.15),
    ("0801-dev-nina", "nina-atlas", "nina.alvarez@cascadeoutfitters.com", "r5.4xlarge", 4, 0, 18, date(2026, 8, 3), {}, 0.45),
    ("0801-dev-stratus1", "stratus-migration-1", "dev1@stratuspartners.io", "r5.8xlarge", 8, 0, 36, date(2026, 8, 1), {}, 0.50),
    ("0801-dev-stratus2", "stratus-migration-2", "dev2@stratuspartners.io", "r5.8xlarge", 8, 0, 36, date(2026, 8, 1), {}, 0.50),
    ("0815-dev-sam", "sam-campaign-analysis", "sam.okafor@cascadeoutfitters.com", "r5.4xlarge", 4, 120, 18, date(2026, 8, 17), {"CostCenter": "CC-200"}, 0.10),
    ("0901-dev-eli", "eli-close-auto", "eli.brooks@cascadeoutfitters.com", "m6i.2xlarge", 2, 60, 9, date(2026, 9, 1), {"cost_center": "CC-500"}, 0.0),
    ("0905-dev-stratus3", "stratus-migration-3", "dev3@stratuspartners.io", "r5.8xlarge", 8, 0, 36, date(2026, 9, 7), {}, 0.50),
]
for c in DEV_CLUSTERS:
    cluster_row(c[0], c[1], c[2], dt(c[7], 9), c[3], c[3], c[4], c[5], c[8], None, "15.4 LTS", dt(c[7], 9))

AP_SKU, AP_PRODUCT = "PREMIUM_ALL_PURPOSE_COMPUTE", "ALL_PURPOSE"

for d in DAYS:
    # shared cluster: weekday business hours, auto-terminates
    if weekday(d):
        for h in range(8, 19):
            emit(WS_PROD, AP_SKU, AP_PRODUCT, dt(d, h), SHARED["dbu"] * random.uniform(0.8, 1.1), SHARED["tags"],
                 SHARED["owner"], SHARED["owner"], cluster_id=SHARED["cid"])
    # atlas GPU: 24x7 from creation
    for h in range(24):
        t = dt(d, h)
        if t >= ATLAS["start"]:
            emit(WS_PROD, AP_SKU, AP_PRODUCT, t, ATLAS["dbu"] * random.uniform(0.97, 1.0), ATLAS["tags"],
                 ATLAS["owner"], ATLAS["owner"], cluster_id=ATLAS["cid"])

# dev clusters: work hours + "forgot to stop it" overnights / weekends for autoterm=0
for c in DEV_CLUSTERS:
    cid, _, owner, _, _, autoterm, dbu, start, tags, p_over = c
    left_running = False
    for d in DAYS:
        if d < start:
            continue
        hours = set()
        if left_running:
            if not weekday(d):
                hours.update(range(24))          # nobody stops it over the weekend
            else:
                hours.update(range(0, 9))        # still up from last night until the owner logs in
                left_running = False
        if weekday(d) and random.random() < 0.85:
            s = random.choice([8, 9, 9, 10])
            e = min(s + random.randint(5, 9), 24)
            hours.update(range(s, e))
            if autoterm == 0 and random.random() < p_over:
                hours.update(range(e, 24))       # auto-termination disabled -> runs overnight
                left_running = True
            elif autoterm >= 120:
                hours.update(range(e, min(e + 2, 24)))  # long idle tail before auto-termination
        for h in sorted(hours):
            emit(WS_DEV, AP_SKU, AP_PRODUCT, dt(d, h), dbu * random.uniform(0.85, 1.05), tags, owner, owner, cluster_id=cid)

# --- Jobs --------------------------------------------------------------------
JOBS = [
    # job_id, name, creator/run_as, tags, sku kind
    (101, "orders_bronze_to_gold", "alex.kim@cascadeoutfitters.com", {"cost_center": "CC-100", "env": "prod"}, "classic"),
    (102, "customer_360_refresh", "jordan.patel@cascadeoutfitters.com", {"cost_center": "CC-200", "env": "prod"}, "serverless"),
    (103, "inventory_forecast_daily", "tom.becker@cascadeoutfitters.com", {"cost_center": "CC-300", "env": "prod"}, "classic"),
    (104, "finance_month_close", "dana.white@cascadeoutfitters.com", {"cost_center": "CC-500", "env": "prod"}, "classic"),
    (105, "atlas_feature_pipeline", "raj.mehta@cascadeoutfitters.com", {"cost_center": "CC-400", "env": "prod", "project": "recsys"}, "serverless"),
    (106, "atlas_model_training_weekly", "chris.wong@cascadeoutfitters.com", {"cost_center": "CC-400", "project": "recsys"}, "serverless"),
    (107, "legacy_clickstream_backfill", "dev1@stratuspartners.io", {}, "classic"),
    (108, "marketing_attribution_nightly", "sam.okafor@cascadeoutfitters.com", {"CostCenter": "CC-200"}, "serverless"),
    (109, "supplier_scorecards", "priya.nair@cascadeoutfitters.com", {"cost_center": "CC-300"}, "classic"),
]
JOB_CREATED = {101: date(2025, 3, 1), 102: date(2025, 5, 1), 103: date(2025, 9, 1), 104: date(2025, 2, 1),
               105: date(2026, 7, 15), 106: date(2026, 7, 20), 107: date(2026, 8, 1), 108: date(2026, 1, 10), 109: date(2025, 10, 1)}

run_counter = [500000]

def run_job(job, start, minutes, dbu_total, fail_p=0.02):
    job_id, _, run_as, tags, kind = job
    run_counter[0] += 1
    run_id = run_counter[0]
    state = "FAILED" if random.random() < fail_p else "SUCCEEDED"
    if state == "FAILED":
        minutes, dbu_total = minutes * random.uniform(0.3, 0.9), dbu_total * random.uniform(0.3, 0.9)
    end = start + timedelta(minutes=minutes)
    runs.append((ACCOUNT_ID, WS_PROD, job_id, run_id, start, end, "CRON", "JOB_RUN", state))
    if kind == "classic":
        emit(WS_PROD, "PREMIUM_JOBS_COMPUTE", "JOBS", start.replace(minute=0), dbu_total, tags, run_as,
             cluster_id=f"job-{job_id}-run-{run_id}", job_id=job_id, job_run_id=run_id)
    else:
        emit(WS_PROD, "PREMIUM_JOBS_SERVERLESS_COMPUTE_US_EAST", "JOBS", start.replace(minute=0), dbu_total, tags,
             run_as, job_id=job_id, job_run_id=run_id, serverless=True)
    return state

J = {j[0]: j for j in JOBS}
INVENTORY_BUG = dt(date(2026, 8, 25), 16)
for d in DAYS:
    run_job(J[101], dt(d, 2, 5), random.uniform(70, 95), random.uniform(1100, 1400))
    run_job(J[101], dt(d, 14, 5), random.uniform(60, 80), random.uniform(1000, 1250))
    run_job(J[102], dt(d, 5, 30), random.uniform(40, 55), random.uniform(330, 380))
    run_job(J[108], dt(d, 3, 0), random.uniform(30, 45), random.uniform(170, 210))
    if weekday(d):
        run_job(J[109], dt(d, 6, 0), random.uniform(20, 30), random.uniform(260, 320))
    # inventory forecast: daily at 04:00 until a cron edit on Aug 25 turned it into "every 15 minutes"
    if d <= INVENTORY_BUG.date():
        run_job(J[103], dt(d, 4, 0), random.uniform(35, 50), random.uniform(500, 620))
    for q in range(96):
        t = dt(d) + timedelta(minutes=15 * q)
        if t >= INVENTORY_BUG:
            run_job(J[103], t, random.uniform(9, 13), random.uniform(17, 23))
    # finance close: first 3 business days of each month, heavy
    bdays = [x for x in DAYS if x.month == d.month and weekday(x)][:3]
    if d in bdays:
        for h in (1, 7, 13, 19):
            run_job(J[104], dt(d, h), random.uniform(50, 80), random.uniform(900, 1100))
    # Project Atlas (launched mid-July): legit, value-generating workload
    if d >= JOB_CREATED[105]:
        ramp = min(1.0, 0.4 + (d - JOB_CREATED[105]).days / 45)
        for h in (1, 9, 17):
            run_job(J[105], dt(d, h), random.uniform(40, 60), 300 * ramp * random.uniform(0.9, 1.1))
    if d >= JOB_CREATED[106] and d.weekday() == 6:
        run_job(J[106], dt(d, 0, 30), random.uniform(300, 420), random.uniform(1700, 2000), fail_p=0.1)
    # Stratus contractor backfill: daily, fails a lot (retries 3x), output table has no readers
    if d >= JOB_CREATED[107]:
        for attempt in range(4):
            st = run_job(J[107], dt(d, 1 + attempt * 2), random.uniform(80, 110), random.uniform(1300, 1500), fail_p=0.65)
            if st == "SUCCEEDED":
                break

# --- Serverless SQL warehouses ----------------------------------------------
WAREHOUSES = []
SQL_SKU = "PREMIUM_SERVERLESS_SQL_COMPUTE_US_EAST"
BI_ID, ADHOC_ID = "wh-bi-exec-01", "wh-adhoc-02"
BI_RESIZE = dt(date(2026, 9, 8), 10)
WAREHOUSES.append((ACCOUNT_ID, WS_PROD, BI_ID, "bi-exec-dashboards", "SERVERLESS", "Medium", 1, 1, 10,
                   {"cost_center": "CC-500"}, dt(date(2025, 6, 1))))
WAREHOUSES.append((ACCOUNT_ID, WS_PROD, BI_ID, "bi-exec-dashboards", "SERVERLESS", "X-Large", 1, 4, 120,
                   {"cost_center": "CC-500"}, BI_RESIZE))
WAREHOUSES.append((ACCOUNT_ID, WS_PROD, ADHOC_ID, "adhoc-analysts", "SERVERLESS", "Small", 1, 2, 10,
                   {}, dt(date(2025, 6, 1))))
SIZE_DBU = {"Small": 12, "Medium": 24, "X-Large": 80}

for d in DAYS:
    for h in range(24):
        t = dt(d, h)
        if t < BI_RESIZE:
            if weekday(d) and 7 <= h < 19:
                emit(WS_PROD, SQL_SKU, "SQL", t, SIZE_DBU["Medium"] * random.uniform(0.55, 1.0), {"cost_center": "CC-500"},
                     "dana.white@cascadeoutfitters.com", warehouse_id=BI_ID, serverless=True, photon=True)
        else:
            # scheduled 15-minute dashboard refresh 06:00-22:00 every day keeps it warm; 120 min auto-stop
            if 6 <= h < 22 or (h in (22, 23)):
                scale = random.uniform(1.0, 1.4) if (weekday(d) and 9 <= h < 11) else 1.0
                emit(WS_PROD, SQL_SKU, "SQL", t, SIZE_DBU["X-Large"] * scale, {"cost_center": "CC-500"},
                     "dana.white@cascadeoutfitters.com", warehouse_id=BI_ID, serverless=True, photon=True)
        if weekday(d) and 8 <= h < 18 and random.random() < 0.9:
            emit(WS_PROD, SQL_SKU, "SQL", t, SIZE_DBU["Small"] * random.uniform(0.5, 1.3), {},
                 "jordan.patel@cascadeoutfitters.com", warehouse_id=ADHOC_ID, serverless=True, photon=True)

# --- Lakeflow pipelines (Lakeflow Connect ingestion + declarative ETL) -------
PIPELINES = []
SFDC_ID, ORDERS_DLT_ID = "pl-sfdc-ingest", "pl-orders-sdp"
SFDC_CONT = dt(date(2026, 8, 5), 11)
PIPELINES.append((ACCOUNT_ID, WS_PROD, SFDC_ID, "salesforce_crm_ingest", "INGESTION", "maria.lopez@cascadeoutfitters.com",
                  {"connector": "salesforce", "continuous": "false", "trigger": "daily 04:00", "serverless": "true"},
                  {"cost_center": "CC-100"}, dt(date(2026, 3, 2))))
PIPELINES.append((ACCOUNT_ID, WS_PROD, SFDC_ID, "salesforce_crm_ingest", "INGESTION", "maria.lopez@cascadeoutfitters.com",
                  {"connector": "salesforce", "continuous": "true", "serverless": "true"},
                  {"cost_center": "CC-100"}, SFDC_CONT))
PIPELINES.append((ACCOUNT_ID, WS_PROD, ORDERS_DLT_ID, "orders_streaming_silver", "ETL", "alex.kim@cascadeoutfitters.com",
                  {"continuous": "false", "trigger": "hourly", "serverless": "true"},
                  {"cost_center": "CC-100"}, dt(date(2025, 8, 1))))
DLT_SKU = "PREMIUM_DLT_SERVERLESS_COMPUTE_US_EAST"
for d in DAYS:
    for h in range(24):
        t = dt(d, h)
        # orders pipeline: hourly triggered, small
        emit(WS_PROD, DLT_SKU, "DLT", t, random.uniform(14, 18), {"cost_center": "CC-100"},
             "alex.kim@cascadeoutfitters.com", pipeline_id=ORDERS_DLT_ID, serverless=True, photon=True)
        if t < SFDC_CONT:
            if h == 4:
                emit(WS_PROD, DLT_SKU, "LAKEFLOW_CONNECT", t, random.uniform(20, 26), {"cost_center": "CC-100"},
                     "maria.lopez@cascadeoutfitters.com", pipeline_id=SFDC_ID, serverless=True)
        else:
            emit(WS_PROD, DLT_SKU, "LAKEFLOW_CONNECT", t, random.uniform(22, 27), {"cost_center": "CC-100"},
                 "maria.lopez@cascadeoutfitters.com", pipeline_id=SFDC_ID, serverless=True)

# --- Model serving (Atlas recommendations endpoint) --------------------------
SERVE_START = dt(date(2026, 8, 1))
for d in DAYS:
    for h in range(24):
        t = dt(d, h)
        if t >= SERVE_START:
            traffic = 1.0 if t >= dt(date(2026, 9, 1)) else 0.5   # 50% A/B in Aug, 100% from Sep
            diurnal = 0.5 + 0.5 * (1 if 8 <= h < 23 else 0)
            emit(WS_PROD, "PREMIUM_SERVERLESS_REAL_TIME_INFERENCE_US_EAST", "MODEL_SERVING", t,
                 120 * traffic * diurnal * random.uniform(0.9, 1.1), {"cost_center": "CC-400", "project": "recsys"},
                 "raj.mehta@cascadeoutfitters.com", endpoint="atlas-recs-v2", serverless=True)

# COMMAND ----------

# MAGIC %md ## Jobs metadata, audit trail, budgets, business KPIs

# COMMAND ----------

lakeflow_jobs = [(ACCOUNT_ID, WS_PROD, j[0], j[1], j[2], j[2], dict(j[3]), dt(JOB_CREATED[j[0]]),
                  None) for j in JOBS]
# the inventory job's SCD row after the schedule edit
lakeflow_jobs.append((ACCOUNT_ID, WS_PROD, 103, "inventory_forecast_daily", "tom.becker@cascadeoutfitters.com",
                      "tom.becker@cascadeoutfitters.com", {"cost_center": "CC-300", "env": "prod"}, INVENTORY_BUG, None))

AUDIT = [
    # event_time, user, service, action, request_params
    (dt(date(2026, 7, 18), 15, 2), "lena.fischer@cascadeoutfitters.com", "clusters", "create",
     {"cluster_name": "atlas-gpu-exploration", "node_type_id": "g5.12xlarge", "num_workers": "4", "autotermination_minutes": "0"}),
    (dt(date(2026, 8, 1), 9, 40), "dev1@stratuspartners.io", "jobs", "create",
     {"job_name": "legacy_clickstream_backfill", "max_retries": "3", "schedule": "0 0 1 * * ?"}),
    (dt(date(2026, 8, 1), 10, 5), "dev1@stratuspartners.io", "clusters", "create", {"cluster_name": "stratus-migration-1", "autotermination_minutes": "0"}),
    (dt(date(2026, 8, 1), 10, 9), "dev2@stratuspartners.io", "clusters", "create", {"cluster_name": "stratus-migration-2", "autotermination_minutes": "0"}),
    (dt(date(2026, 8, 5), 11, 0), "maria.lopez@cascadeoutfitters.com", "pipelines", "edit",
     {"pipeline_name": "salesforce_crm_ingest", "continuous": "true"}),
    (dt(date(2026, 8, 25), 16, 0), "tom.becker@cascadeoutfitters.com", "jobs", "update",
     {"job_name": "inventory_forecast_daily", "old_schedule": "0 0 4 * * ?", "new_schedule": "0 0/15 * * * ?"}),
    (dt(date(2026, 9, 8), 10, 0), "dana.white@cascadeoutfitters.com", "databrickssql", "editWarehouse",
     {"warehouse_name": "bi-exec-dashboards", "cluster_size": "X-Large", "max_num_clusters": "4", "auto_stop_mins": "120"}),
    (dt(date(2026, 9, 8), 10, 20), "dana.white@cascadeoutfitters.com", "dashboards", "createSchedule",
     {"dashboard_name": "Executive Daily Pulse", "cron": "0 0/15 6-22 * * ?", "warehouse": "bi-exec-dashboards"}),
    (dt(date(2026, 9, 7), 9, 30), "dev3@stratuspartners.io", "clusters", "create", {"cluster_name": "stratus-migration-3", "autotermination_minutes": "0"}),
]
access_audit = [(rid("a", i), ACCOUNT_ID, WS_PROD if a[2] != "clusters" or "atlas" in str(a[4]) else WS_DEV,
                 a[0], a[0].date(), a[1], a[2], a[3], a[4], 200) for i, a in enumerate(AUDIT)]

BUDGETS = [  # cost_center, quarter, approved_budget_usd
    ("CC-100", "2026-Q3", 75000), ("CC-200", "2026-Q3", 24000), ("CC-300", "2026-Q3", 12000),
    ("CC-400", "2026-Q3", 30000), ("CC-500", "2026-Q3", 18000), ("UNALLOCATED", "2026-Q3", 6000),
    ("CC-100", "2026-Q4", 78000), ("CC-200", "2026-Q4", 25000), ("CC-300", "2026-Q4", 12000),
    ("CC-400", "2026-Q4", 45000), ("CC-500", "2026-Q4", 18000), ("UNALLOCATED", "2026-Q4", 6000),
]

biz = []
wk = date(2026, 6, 1)
while wk <= END:
    sessions = int(4_100_000 * random.uniform(0.96, 1.04) * (1 + (wk - START).days * 0.0012))
    base_cr = 0.0262 * random.uniform(0.98, 1.02)
    if wk >= date(2026, 9, 1):
        exposure = 1.0
    elif wk >= date(2026, 8, 3):
        exposure = 0.5
    else:
        exposure = 0.0
    lift = 0.024 * exposure            # measured A/B lift in conversion from recs
    cr = base_cr * (1 + lift)
    aov = 108 * random.uniform(0.98, 1.02)
    rev = sessions * cr * aov
    incr = rev - rev / (1 + lift)
    biz.append((wk, sessions, round(cr, 5), round(aov, 2), round(rev, 2), round(incr, 2), exposure))
    wk += timedelta(days=7)

# COMMAND ----------

# MAGIC %md ## Write to Unity Catalog

# COMMAND ----------

if ON_DATABRICKS:
    from pyspark.sql.types import (StructType, StructField, StringType, LongType, DoubleType, TimestampType,
                                   DateType, MapType, BooleanType, IntegerType)
    spark.conf.set("spark.sql.session.timeZone", "UTC")
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
    M = MapType(StringType(), StringType())

    schemas = {
        "billing_usage": (usage, StructType([
            StructField("record_id", StringType()), StructField("account_id", StringType()),
            StructField("workspace_id", LongType()), StructField("sku_name", StringType()),
            StructField("cloud", StringType()), StructField("usage_start_time", TimestampType()),
            StructField("usage_end_time", TimestampType()), StructField("usage_date", DateType()),
            StructField("custom_tags", M), StructField("usage_unit", StringType()),
            StructField("usage_quantity", DoubleType()),
            StructField("usage_metadata", StructType([
                StructField("cluster_id", StringType()), StructField("job_id", LongType()),
                StructField("job_run_id", LongType()), StructField("warehouse_id", StringType()),
                StructField("dlt_pipeline_id", StringType()), StructField("endpoint_name", StringType())])),
            StructField("identity_metadata", StructType([
                StructField("run_as", StringType()), StructField("owned_by", StringType())])),
            StructField("record_type", StringType()), StructField("billing_origin_product", StringType()),
            StructField("product_features", StructType([
                StructField("is_serverless", BooleanType()), StructField("is_photon", BooleanType())])),
        ])),
        "billing_list_prices": ([(s, CLOUD, "USD", u, (p,), st, en) for s, u, p, st, en in LIST_PRICES], StructType([
            StructField("sku_name", StringType()), StructField("cloud", StringType()),
            StructField("currency_code", StringType()), StructField("usage_unit", StringType()),
            StructField("pricing", StructType([StructField("default", DoubleType())])),
            StructField("price_start_time", TimestampType()), StructField("price_end_time", TimestampType())])),
        "compute_clusters": (clusters_scd, StructType([
            StructField("account_id", StringType()), StructField("workspace_id", LongType()),
            StructField("cluster_id", StringType()), StructField("cluster_name", StringType()),
            StructField("owned_by", StringType()), StructField("create_time", TimestampType()),
            StructField("delete_time", TimestampType()), StructField("driver_node_type", StringType()),
            StructField("worker_node_type", StringType()), StructField("worker_count", LongType()),
            StructField("min_autoscale_workers", LongType()), StructField("max_autoscale_workers", LongType()),
            StructField("auto_termination_minutes", LongType()), StructField("tags", M),
            StructField("cluster_source", StringType()), StructField("policy_id", StringType()),
            StructField("dbr_version", StringType()), StructField("change_time", TimestampType())])),
        "compute_warehouses": (WAREHOUSES, StructType([
            StructField("account_id", StringType()), StructField("workspace_id", LongType()),
            StructField("warehouse_id", StringType()), StructField("warehouse_name", StringType()),
            StructField("warehouse_type", StringType()), StructField("warehouse_size", StringType()),
            StructField("min_clusters", LongType()), StructField("max_clusters", LongType()),
            StructField("auto_stop_minutes", LongType()), StructField("tags", M),
            StructField("change_time", TimestampType())])),
        "lakeflow_jobs": (lakeflow_jobs, StructType([
            StructField("account_id", StringType()), StructField("workspace_id", LongType()),
            StructField("job_id", LongType()), StructField("name", StringType()),
            StructField("creator_id", StringType()), StructField("run_as", StringType()),
            StructField("tags", M), StructField("change_time", TimestampType()),
            StructField("delete_time", TimestampType())])),
        "lakeflow_job_run_timeline": (runs, StructType([
            StructField("account_id", StringType()), StructField("workspace_id", LongType()),
            StructField("job_id", LongType()), StructField("run_id", LongType()),
            StructField("period_start_time", TimestampType()), StructField("period_end_time", TimestampType()),
            StructField("trigger_type", StringType()), StructField("run_type", StringType()),
            StructField("result_state", StringType())])),
        "lakeflow_pipelines": (PIPELINES, StructType([
            StructField("account_id", StringType()), StructField("workspace_id", LongType()),
            StructField("pipeline_id", StringType()), StructField("name", StringType()),
            StructField("pipeline_type", StringType()), StructField("created_by", StringType()),
            StructField("settings", M), StructField("tags", M), StructField("change_time", TimestampType())])),
        "access_audit": (access_audit, StructType([
            StructField("event_id", StringType()), StructField("account_id", StringType()),
            StructField("workspace_id", LongType()), StructField("event_time", TimestampType()),
            StructField("event_date", DateType()), StructField("user_email", StringType()),
            StructField("service_name", StringType()), StructField("action_name", StringType()),
            StructField("request_params", M), StructField("response_status_code", IntegerType())])),
        "ref_team_directory": (TEAM_DIRECTORY, StructType([
            StructField("email", StringType()), StructField("display_name", StringType()),
            StructField("team", StringType()), StructField("cost_center", StringType()),
            StructField("manager", StringType()), StructField("employment_type", StringType())])),
        "ref_budgets": (BUDGETS, StructType([
            StructField("cost_center", StringType()), StructField("quarter", StringType()),
            StructField("approved_budget_usd", LongType())])),
        "biz_kpis_weekly": (biz, StructType([
            StructField("week_start", DateType()), StructField("sessions", LongType()),
            StructField("conversion_rate", DoubleType()), StructField("avg_order_value", DoubleType()),
            StructField("online_revenue_usd", DoubleType()), StructField("recs_incremental_revenue_usd", DoubleType()),
            StructField("recs_traffic_exposure", DoubleType())])),
    }
    for name, (rows, schema) in schemas.items():
        (spark.createDataFrame(rows, schema).write.mode("overwrite")
         .option("overwriteSchema", "true").saveAsTable(f"{CATALOG}.{SCHEMA}.{name}"))
        print(f"wrote {CATALOG}.{SCHEMA}.{name}: {len(rows):,} rows")
else:
    print(f"usage rows: {len(usage):,}  job runs: {len(runs):,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ✅ Done. Next: `src/01_transform/build_cost_fact` (the job runs it automatically after this task).
